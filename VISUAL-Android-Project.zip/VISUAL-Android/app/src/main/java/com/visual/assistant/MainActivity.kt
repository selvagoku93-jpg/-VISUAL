package com.visual.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val cyan = Color.rgb(0, 220, 255)
    private val dark = Color.rgb(4, 10, 25)
    private val worker = Executors.newSingleThreadExecutor()

    private lateinit var apiKeyBox: EditText
    private lateinit var questionBox: EditText
    private lateinit var chatBox: TextView
    private lateinit var statusBox: TextView
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark
        window.navigationBarColor = dark
        tts = TextToSpeech(this, this)
        buildScreen()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 26, 22, 18)
            setBackgroundColor(dark)
        }

        val title = TextView(this).apply {
            text = "V I S U A L"
            textSize = 30f
            setTextColor(cyan)
            typeface = Typeface.create("sans-serif-light", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        page.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "PERSONAL AI ASSISTANT"
            textSize = 11f
            letterSpacing = 0.25f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        page.addView(subtitle, matchWrap())

        statusBox = TextView(this).apply {
            text = "● SYSTEM ONLINE"
            textSize = 13f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 18)
        }
        page.addView(statusBox, matchWrap())

        apiKeyBox = EditText(this).apply {
            hint = "Gemini API key (AIza...)"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 14f
            setSingleLine(true)
            inputType = 0x00000081 // text + password
            setBackgroundColor(Color.rgb(15, 28, 48))
            setPadding(14, 12, 14, 12)
        }
        page.addView(apiKeyBox, matchWrap())

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(8, 18, 35))
        }
        chatBox = TextView(this).apply {
            text = "VISUAL: வணக்கம்! நான் VISUAL. என்ன உதவி வேண்டும்?"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(14, 16, 14, 16)
        }
        scroll.addView(chatBox)
        val scrollParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ).apply { topMargin = 16; bottomMargin = 12 }
        page.addView(scroll, scrollParams)

        questionBox = EditText(this).apply {
            hint = "Type in Tamil or English..."
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 16f
            setBackgroundColor(Color.rgb(15, 28, 48))
            setPadding(14, 12, 14, 12)
        }
        page.addView(questionBox, matchWrap())

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val mic = makeButton("🎙 SPEAK") { startListening() }
        val send = makeButton("SEND ➤") { sendQuestion() }
        buttons.addView(mic, LinearLayout.LayoutParams(0, 54, 1f).apply { rightMargin = 6 })
        buttons.addView(send, LinearLayout.LayoutParams(0, 54, 1f).apply { leftMargin = 6 })
        page.addView(buttons, matchWrap())

        val stop = makeButton("STOP VOICE") {
            tts?.stop()
            statusBox.text = "● READY"
        }
        page.addView(stop, matchWrap())

        setContentView(page)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun makeButton(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 13f
            setTextColor(dark)
            setBackgroundColor(cyan)
            setOnClickListener { action() }
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("இந்த மொபைலில் Speech Recognition கிடைக்கவில்லை")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41)
            return
        }
        try {
            if (speechRecognizer == null) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
                speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        statusBox.text = "● LISTENING..."
                    }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { statusBox.text = "● THINKING..." }
                    override fun onError(error: Int) {
                        statusBox.text = "● READY"
                        toast("குரலை மீண்டும் முயற்சி செய்யுங்கள்")
                    }
                    override fun onResults(results: Bundle?) {
                        val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        questionBox.setText(words?.firstOrNull().orEmpty())
                        sendQuestion()
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ta-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "VISUAL-ிடம் பேசுங்கள்")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            toast("Microphone தொடங்க முடியவில்லை: ${e.message}")
        }
    }

    private fun sendQuestion() {
        val question = questionBox.text.toString().trim()
        val key = apiKeyBox.text.toString().trim()
        if (key.isBlank()) {
            toast("முதலில் Gemini API key உள்ளிடுங்கள்")
            return
        }
        if (question.isBlank()) {
            toast("ஒரு கேள்வியை உள்ளிடுங்கள்")
            return
        }

        appendChat("\n\nYOU: $question")
        questionBox.text.clear()
        statusBox.text = "● THINKING..."
        tts?.stop()

        worker.execute {
            try {
                val answer = askGemini(key, question)
                runOnUiThread {
                    appendChat("\n\nVISUAL: $answer")
                    statusBox.text = "● SPEAKING..."
                    tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "visual_reply")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusBox.text = "● ERROR"
                    appendChat("\n\nVISUAL ERROR: ${e.message ?: "Unknown error"}")
                }
            }
        }
    }

    private fun askGemini(key: String, question: String): String {
        val endpoint = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=$key"
        )
        val payload = JSONObject()
            .put("system_instruction", JSONObject().put("parts", org.json.JSONArray().put(
                JSONObject().put(
                    "text",
                    "You are VISUAL, a friendly and helpful JARVIS-style personal assistant. " +
                    "Reply naturally in the same language as the user. Support Tamil and English. " +
                    "Keep answers clear and concise."
                )
            )))
            .put("contents", org.json.JSONArray().put(
                JSONObject().put("role", "user").put(
                    "parts", org.json.JSONArray().put(JSONObject().put("text", question))
                )
            ))

        val connection = (endpoint.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }

        try {
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) {
                throw Exception("Gemini API $code: ${response.take(350)}")
            }
            val json = JSONObject(response)
            return json.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
        } finally {
            connection.disconnect()
        }
    }

    private fun appendChat(message: String) {
        chatBox.append(message)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("ta", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA ||
                result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.US)
            }
        }
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else if (requestCode == 41) {
            toast("Microphone permission தேவை")
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        worker.shutdown()
        super.onDestroy()
    }
}
